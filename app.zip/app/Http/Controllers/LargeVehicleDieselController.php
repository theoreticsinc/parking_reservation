<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LargeVehicleDieselController extends Controller
{
    public function index()
    {
        return view('largevehiclediesel');
    }
}
