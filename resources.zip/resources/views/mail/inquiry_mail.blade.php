<!DOCTYPE html>

<html>
<head>
<title></title>
<meta charset="utf-8"/>
<meta content="width=device-width" name="viewport"/>
</head>
<body>
<div class="bee-page-container">
<div class="bee-row bee-row-1">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:15px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-2">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:30px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-3">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w1">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
<div class="bee-col bee-col-2 bee-col-w5">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:20px;"></div>
</div>
<div class="bee-block bee-block-2 bee-heading">
<h1 style="color:#199e59;direction:ltr;font-family:'Roboto Slab', Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size:74px;font-weight:700;letter-spacing:normal;line-height:120%;text-align:left;margin-top:0;margin-bottom:0;">
	Inquiry from ParkNFly.com.ph<br/> </h1>
</div>
<div class="bee-block bee-block-3 bee-paragraph">
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br/>Enim nisl, eget dictum consectetur integer lectus.</p>
</div>
<div class="bee-col bee-col-3 bee-col-w6"></div>
</div>
</div>
<div class="bee-row bee-row-4">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12">
<div class="bee-block bee-block-1 bee-paragraph">
<p>Welcome!</p>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-5">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
<div class="bee-col bee-col-2 bee-col-w8">
<div class="bee-block bee-block-1 bee-paragraph">
<p><strong>Hello Sir </strong><br/><strong>Your Request is confirm on this data. </strong></p>
</div>{{ $formData['fullname'] }} </div>
</div>{{ $formData['mobile'] }} </div>
</div>{{ $formData['message'] }} </div>

<p>Aliquam purus commodo magnis ipsum dolor sit amet, consectetur adipiscing elit habitasse est in rhoncus libero ut. Aenean viverra fermentum, volutpat, neque amet, justo.<br/>Socis natoqu eagnis dist mte dulmuese feugiata lecen erment.</p>
</div>
<div class="bee-col bee-col-3 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-6">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12"></div>
</div>
</div>
<div class="bee-row bee-row-7">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
<div class="bee-col bee-col-2 bee-col-w8"></div>
<div class="bee-col bee-col-3 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-8">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
<div class="bee-col bee-col-2 bee-col-w4"></div>
<div class="bee-col bee-col-3 bee-col-w4"></div>
<div class="bee-col bee-col-4 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-9">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
<div class="bee-col bee-col-2 bee-col-w4"></div>
<div class="bee-col bee-col-3 bee-col-w4"></div>
<div class="bee-col bee-col-4 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-10">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:60px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-11">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12"></div>
</div>
</div>
<div class="bee-row bee-row-12">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
<div class="bee-col bee-col-2 bee-col-w8"></div>
<div class="bee-col bee-col-3 bee-col-w2">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:1px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-13">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12">
<div class="bee-block bee-block-1 bee-spacer">
<div class="spacer" style="height:20px;"></div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-14">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w3"></div>
<div class="bee-col bee-col-2 bee-col-w3">
<div class="bee-block bee-block-1 bee-text">
<div class="bee-text-content" style="line-height: 120%; font-size: 12px; font-family: inherit; color: #fafafa;">
<p style="font-size: 14px; line-height: 16px; text-align: center;"><span style="font-size: 18px; line-height: 21px;"><strong style=""><span style="line-height: 14px;">About</span></strong></span></p>
</div>
</div>
<div class="bee-block bee-block-2 bee-text">
<div class="bee-text-content" style="line-height: 150%; font-size: 12px; font-family: inherit; color: #fafafa;">
<p style="line-height: 18px; text-align: center;"><span style="line-height: 18px;">{{ $formData['fullname'] }} </span></p>
<p style="line-height: 18px; text-align: center;"><span style="line-height: 18px;">{{ $formData['mobile'] }} </span></p>
<p style="line-height: 18px; text-align: center;"><span style="line-height: 18px;">{{ $formData['message'] }} </span></p>
</div>
</div>
</div>
<div class="bee-col bee-col-3 bee-col-w3">
<div class="bee-block bee-block-1 bee-text">
<div class="bee-text-content" style="line-height: 120%; font-size: 12px; font-family: inherit; color: #fafafa;">
<p style="font-size: 14px; line-height: 16px; text-align: center;"><span style="font-size: 18px; line-height: 21px;"><strong style=""><span style="line-height: 14px;">Contact Us</span></strong></span></p>
</div>
</div>
</div>
<div class="bee-col bee-col-4 bee-col-w3"></div>
</div>
</div>
<div class="bee-row bee-row-15">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12">
<div class="bee-block bee-block-1 bee-text">
<div class="bee-text-content" style="line-height: 120%; font-size: 12px; font-family: inherit; color: #868686;">
<p style="font-size: 14px; line-height: 16px; text-align: center;"><span style="font-size: 12px; line-height: 14px;">2022 © All Rights Reserved</span></p>
</div>
</div>
</div>
</div>
</div>
<div class="bee-row bee-row-16">
<div class="bee-row-content">
<div class="bee-col bee-col-1 bee-col-w12">
<div class="bee-block bee-block-1 bee-icons">
<div class="bee-icon bee-icon-last">
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>