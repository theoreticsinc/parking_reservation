<footer class="page-footer">
	<p class="mb-0">Copyright © 2024. All rights reserved.</p>
</footer>