<header class="top-header top-header-bg">
  <div class="container">
      <div class="row align-items-center">
          <div class="col-lg-3 col-md-2 pr-0">
              
          </div>

          <div class="col-lg-9 col-md-10">
              <div class="header-right">
                  <ul>
                      <li>
                          <i class='bx bx-home-alt'></i>
                          <a href="#">Mia Road Corner Domestic Road Airport,&nbsp; Pasay City</a>
                      </li>
                      <li>
                          <i class='bx bx-phone-call'></i>
                          <a href="tel:+639189910000">(+63)918-991-0000</a>
                      </li>


                    <li>
                        <i class="bx bx-credit-card"></i>
                        <a href="{{ route('cart.index') }}"> CART : Php {{ Cart::subtotal() }} </a>
                    </li>
                  </ul>
              </div>
          </div>
      </div>
  </div>
</header>

